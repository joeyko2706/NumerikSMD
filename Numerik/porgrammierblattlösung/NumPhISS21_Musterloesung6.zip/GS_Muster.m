%%  Numerische Mathematik fuer Physik und Ingenieurwissenschaften SS2021
%
%   Prof. Dr. J. Stoeckler
%   M.Sc. M. Weimann
%   Dipl.-Math. M. Bangert
%
%   Musterloesung 6ai
%   Abgabe bis zum 08.07.2021
%
%   Student*in 1: Vorname, Nachname, Matrikelnummer
%   Student*in 2: Vorname, Nachname, Matrikelnummer
%
%   Programmversion: z.B. Matlab R2021a oder Octave 6.2.0
%

function [x,ret] = GS_Muster(A,b,tol,maxiter)

n = length(b);
x_0 = zeros(n,1);

for i=1:n
    x_0(i) = b(i)/A(i,i);
end

ret = [x_0;0];
abb = inf;
k = 1;

% Iteration
x_alt = x_0;  % nur für das Abbruchkriterium verwendet
x = x_0;
while abb > tol
    
    i = 1;
    x(i) = (b(i) - A(i,i+1) * x(i+1))/A(i,i); %x(i+1) gehoert zu k-1
    
    for i=2:n-1
        x(i) = (b(i) - A(i,i-1) * x(i-1) - A(i,i+1) * x(i+1))/A(i,i); %x(i+1) gehoert zu k-1, x(i-1) gehoert zu k
    end
    
    i = n;
    x(i) = (b(i) - A(i,i-1) * x(i-1))/A(i,i); %x(i-1) gehoert zu k
    
    abb =  norm(x-x_alt,Inf);
    
    ret(1:n,k+1) = x;
    ret(n+1,k+1) = abb;
   
    k = k + 1;
    x_alt = x;
    
    if k >= maxiter
        break
    end
end
end