%%  Numerische Mathematik fuer Physik und Ingenieurwissenschaften SS2021
%
%   Prof. Dr. J. Stoeckler
%   M.Sc. M. Weimann
%   Dipl.-Math. M. Bangert
%
%   Musterloesung 4b+4c
%   Abgabe bis zum 03.06.2021
%
%   Student*in 1: Vorname, Nachname, Matrikelnummer
%   Student*in 2: Vorname, Nachname, Matrikelnummer
%
%   Programmversion: z.B. Matlab R2021a oder Octave 6.2.0
%
%% 4b

clear all
close all


f  = @(x)     3  * x.^4 + 18 * x.^3 + 36 * x.^2 + 30 * x + 9;
df = @(x)     12 * x.^3 + 54 * x.^2 + 72 * x    + 30;

x0 = 5;
tol = 10e-12;
k_max = 100;

for p = 1:5
    [x,out] = mod_newton(f, df, p, x0, tol, k_max);
    T = table(out(:,1),out(:,2),out(:,3),out(:,4),'VariableNames',{'k','x', 'f(x)', 'df(x)'});
    disp(['p = ' num2str(p)])
    disp(T)
    disp('-----------------------------------------')
end

%% 4c
%{
f hat eine dreifache Nullstelle in x=-1. Deshalb erwarten wir lokal
quadratische Konvergenz fuer p=3. Fuer p=5 verlassen wir den konvexen
Startbereich und treffen zufaellig direkt die andere Nullstelle.
%}
