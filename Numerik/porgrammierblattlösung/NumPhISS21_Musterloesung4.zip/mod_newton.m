%%  Numerische Mathematik fuer Physik und Ingenieurwissenschaften SS2021
%
%   Prof. Dr. J. Stoeckler
%   M.Sc. M. Weimann
%   Dipl.-Math. M. Bangert
%
%   Musterloesung 4a
%   Abgabe bis zum 03.06.2021
%
%   Student*in 1: Vorname, Nachname, Matrikelnummer
%   Student*in 2: Vorname, Nachname, Matrikelnummer
%
%   Programmversion: z.B. Matlab R2021a oder Octave 6.2.0
%
%%

function [x,ret] = mod_newton(f, df, p, x0, tol, k_max)

k = 0;
x = x0;
fx = f(x);
dfx = df(x);

ret = [k, x, fx, dfx];
err = abs(fx);

while (err > tol)
    
    k = k + 1;
    
    x = x - p * fx/dfx;
    
    fx = f(x);
    dfx = df(x);
    err = abs(fx);
    
    ret(end+1,:) = [k, x, fx, dfx];
%    err = abs(ret(end-1,2) - ret(end,2));
    
    if (k > k_max - 1)
        disp('method does not converge with k_max steps')
        break
    end
    
end

end